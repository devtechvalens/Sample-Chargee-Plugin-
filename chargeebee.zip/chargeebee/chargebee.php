<?php
/*
Plugin Name: ChargeBee
Description:
Version: 1
Author: vijay pancholi
Author URI: https://www.techvalens.com/
*/

if ( ! defined( 'ABSPATH' ) ) {
	die;
}

define('SUSCRIPTION_CHARGEBEE_URL',plugin_dir_url(__FILE__));
define('SUSCRIPTION_CHARGEBEE_DIR', plugin_dir_path(__FILE__));

require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
require_once(SUSCRIPTION_CHARGEBEE_DIR.'files/library.php');
include_once(SUSCRIPTION_CHARGEBEE_DIR. 'controller/Template.php');
include_once(SUSCRIPTION_CHARGEBEE_DIR. 'controller/ChargebeeShorcode.php');
require_once(SUSCRIPTION_CHARGEBEE_DIR.'install.php');