<?php
class ChargebeeLibrary
{
        public $wc_connect_base_url;
        
	   
	   function __construct(){
         
         $this->wc_connect_base_url = SUSCRIPTION_CHARGEBEE_URL;
		 add_action('admin_enqueue_scripts', array($this,'register_css_js_admin_script'));

		}

		public function chargebee_update_option( $option, $value, $autoload = null){
	      return update_option( $option, $value, $autoload);
		}

		public function chargebee_get_edit_post_link($get_edit_post_id){
          return get_edit_post_link($get_edit_post_id);
        }
		

 	    public  function register_css_js_admin_script() {
	    
		wp_register_style( 'custom_wp_admin_css', $this->wc_connect_base_url.'files/css/chargebee.min.css', false, '1.0.0' );
		wp_enqueue_style( 'custom_wp_admin_css' );

		wp_register_style( 'custom_wp_form_css', $this->wc_connect_base_url.'files/css/chargebee.css', false, '1.0.0' );
		wp_enqueue_style( 'custom_wp_form_css' );

		wp_register_style( 'custom_wp_custom_css', $this->wc_connect_base_url.'files/css/custom.css', false, '1.0.0' );
		wp_enqueue_style( 'custom_wp_custom_css' );

		
		wp_enqueue_style( 'subscription_chargebee_datatable_fontIcon', 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
		wp_enqueue_style( 'subscription_chargebee_datatablebot', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css' );

		wp_register_style( 'custom_wp_admin_dataTables.bootstrap.min', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/css/dataTables.bootstrap.min', false, '1.0.0' );
		wp_enqueue_style( 'custom_wp_admin_dataTables.bootstrap.min' );

		wp_register_style( 'custom_wp_admin_dataTables.bootstrap4.min', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/css/dataTables.bootstrap.min.css', false, '1.0.0' );
		wp_enqueue_style( 'custom_wp_admin_dataTables.bootstrap4.min' );

		wp_register_style( 'custom_wp_admin_dataTables.jqueryui.min', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/css/dataTables.bootstrap4.min.css', false, '1.0.0' );
		wp_enqueue_style( 'custom_wp_admin_dataTables.jqueryui.min' );

		wp_register_style( 'custom_wp_admin_dataTables.semanticui.min', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/css/dataTables.jqueryui.min.css', false, '1.0.0' );
		wp_enqueue_style( 'custom_wp_admin_dataTables.semanticui.min' );

		wp_register_style( 'custom_wp_admin_jquery.dataTables.min', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/css/dataTables.semanticui.min.css', false, '1.0.0' );
		wp_enqueue_style( 'custom_wp_admin_jquery.dataTables.min' );

		wp_register_style('custom_subcrition_jquery.dataTables_themeroller' , $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/css/jquery.dataTables_themeroller.css', false, '1.0.0');
		wp_enqueue_style( 'custom_subcrition_jquery.dataTables_themeroller' );

		wp_register_style('custom_subcrition_ukit' , $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/css/dataTables.uikit.min', false, '1.0.0');
		wp_enqueue_style( 'custom_subcrition_ukit' );

		wp_enqueue_style( 'subscription_chargebee_datatable15', 'https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' );
		wp_enqueue_style( 'subscription_chargebee_datatable16', 'https://cdn.datatables.net/rowreorder/1.2.5/css/rowReorder.dataTables.min.css' );
		wp_enqueue_style( 'subscription_chargebee_datatable17', 'https://cdn.datatables.net/responsive/2.2.3/css/responsive.dataTables.min.css' ); 
		wp_enqueue_script( 'subscription_chargebee_datatable12', 'https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js', true );
		wp_enqueue_script( 'subscription_chargebee_datatable13', 'https://cdn.datatables.net/rowreorder/1.2.5/js/dataTables.rowReorder.min.js', true );
		wp_enqueue_script( 'subscription_chargebee_datatable14', 'https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js', true );

		wp_enqueue_script( 'subscription_chargebee_validate', '//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js', true );
		wp_enqueue_script( 'subscription_chargebee_custom_js', $this->wc_connect_base_url.'files/js/custom.js', true );
        wp_enqueue_script( 'subscription_chargebee_datatable_jquery', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/js/jquery.dataTables.min.js', true );
        wp_enqueue_script( 'subscription_chargebee_datatable_bootstrap', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/js/dataTables.bootstrap.min.js', true );
        wp_enqueue_script( 'subscription_chargebee_datatable_datatable', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/js/dataTables.dataTables.min.js', true );
        wp_enqueue_script( 'subscription_chargebee_datatable_jquery', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/js/jquery.js', true );
        wp_enqueue_script( 'subscription_chargebee_datatable_semanticui', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/js/dataTables.semanticui.min.js', true );
        wp_enqueue_script( 'subscription_chargebee_datatable_uikit_min', $this->wc_connect_base_url.'files/js/DataTables-1.10.19/media/js/dataTables.uikit.min.js', true );
	    }

        public function chargebee_sample_admin_notice__success($message){
        $class = 'notice notice-success is-dismissible';
		printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), $message);
        }

        public function chargebee_get_option($option_name){
	      return get_option($option_name);
		}

		public function chargebee_library($domain,$api_key){
                
		}

		public function chargebee_update_post_meta( $option, $value, $autoload = null){
	        return update_post_meta( $option, $value, $autoload);
		}

		public function chargebee_get_post_meta($post_id, $key = '', $single = false){
			
	        return  get_post_meta( $post_id, $key, $single);
		}

		public function get_meta_box_value($id){
		  $price      = $this->chargebee_get_post_meta($id, 'price', true);
		  $description      = $this->chargebee_get_post_meta($id, 'description', true);
          $metabox_title      = $this->chargebee_get_post_meta($id, 'metabox_title', true);
          $metabox_saving     = $this->chargebee_get_post_meta($id, 'metabox_saving', true);
          $metabox_separately = $this->chargebee_get_post_meta($id, 'metabox_separately', true);
          $metabox_include    = $this->chargebee_get_post_meta($id, 'metabox_include', true);
          $metabox_masks      = $this->chargebee_get_post_meta($id, 'metabox_masks', true);
          $metabox_cushions   = $this->chargebee_get_post_meta($id, 'metabox_cushions', true);
          $metabox_tub        = $this->chargebee_get_post_meta($id, 'metabox_tub', true);
          $metabox_filters    = $this->chargebee_get_post_meta($id, 'metabox_filters', true);
          $metabox_tubings    = $this->chargebee_get_post_meta($id, 'metabox_tubings', true);
  
          return array('price' => $price , 'description' => $description  ,'metabox_title' => $metabox_title ,'metabox_saving' => $metabox_saving , 'metabox_separately' => $metabox_separately , 'metabox_include' => $metabox_include , 'metabox_masks' => $metabox_masks , 'metabox_cushions' => $metabox_cushions , 'metabox_tub' => $metabox_tub , 'metabox_filters' => $metabox_filters , 'metabox_tubings' => $metabox_tubings );
    }
    
    public function get_mask_box_value($id){
    	    
			$mask_1     = $this->chargebee_get_post_meta($id, 'mask_1', true);
			$mask_2     = $this->chargebee_get_post_meta($id, 'mask_2', true);
			$mask_3     = $this->chargebee_get_post_meta($id, 'mask_3', true);
			$mask_4     = $this->chargebee_get_post_meta($id, 'mask_4', true);
          
  
          return array('mask_1'=> $mask_1 ,'mask_2' => $mask_2 ,'mask_3' => $mask_3 , 'mask_4' => $mask_4);
    }


}