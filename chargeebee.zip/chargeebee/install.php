<?php

/*Installation code for chargebee*/

class ChargeBeeInstallation{
     protected $lib;
     protected $setting;
	
    public function __construct(){
    	$this->lib = new ChargebeeLibrary(); 

          register_activation_hook(SUSCRIPTION_CHARGEBEE_DIR, array($this, 'activate') );          
            			
    }

  public static function activate()
  { 
       add_action('init',array($this,'load_dependencies'));
  }

	public function load_dependencies(){

         $this->lib->register_css_js_admin_script();
 
         include_once(SUSCRIPTION_CHARGEBEE_DIR. 'controller/Adminsetting.php');
         $this->setting = new AdminSetting();

	}

}

$obj = new ChargeBeeInstallation();