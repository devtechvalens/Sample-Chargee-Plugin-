<?php  
class Setting {

    private $lib;
    public function __construct(){
    require_once(SUSCRIPTION_CHARGEBEE_DIR.'files/library.php');
    $this->lib = new ChargebeeLibrary();     

    }

    public function insertapi(){  
        
        if (isset($_POST['submit']) && $_POST['action']== 'chargebee_action_setting')
        {
        $mode    = $_POST['test_mode'];
        $api_key = $_POST['api_key'];
        $domain  = $_POST['domain'];
        $test_api_key = $_POST['test_api_key'];
        $test_domain = $_POST['test_domain']; 
        
        $this->lib->chargebee_update_option('test_mode',$mode);
        $this->lib->chargebee_update_option('api_key',$api_key);
        $this->lib->chargebee_update_option('domain',$domain);
        $this->lib->chargebee_update_option('test_api_key',$test_api_key);
        $this->lib->chargebee_update_option('test_domain',$test_domain);
       
        $this->lib->chargebee_sample_admin_notice__success('Setting Saved Sucessfully');
        
        }
        
    }

    public function insert_subscription(){  
        
        if (isset($_POST['submit']) && $_POST['action']== 'chargebee_subscription_form_action')
        {
        
        $firstname    = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email  = $_POST['email'];
        $ph_number = $_POST['ph_number'];
        $adr1 = $_POST['adr1'];
        $adr2    = $_POST['adr2'];
        $city = $_POST['city'];
        $state  = $_POST['state'];
        $country = $_POST['country'];
        $zip = $_POST['zip'];
        $cardnumber    = $_POST['cardnumber'];
        $expmonth = $_POST['expmonth'];
        $expyear  = $_POST['expyear'];
        $card_cvv = $_POST['card_cvv'];
        $bill_adr1 = $_POST['bill_adr1'];
        $bill_adr2    = $_POST['bill_adr2'];
        $bill_city = $_POST['bill_city'];
        $bill_state  = $_POST['bill_state'];
        $bill_country = $_POST['bill_country'];
        $bzip = $_POST['bzip'];
        $current_user_id = $_POST['current_user_id'];
        $subscription_product_id  = $_POST['subscription_product_id'];
        $subscription_product_handle = $_POST['subscription_product_handle'];
        $cmd = $_POST['cmd'];
        $chargebee_cid = $_POST['chargebee_cid'];

        $setting = $this->checkmodeapi();  
        $api_key =  $setting['api_key'];
        $domain  =  $setting['domain'];

        $this->lib->chargebee_library($domain,$api_key);

        ChargeBee_Environment::configure($domain,$api_key);
        
        $result = ChargeBee_Subscription::create(array(

        
        "planId" => $subscription_product_id,
        "autoCollection" => "off",
        "billingAddress" => array(
        "firstName" => $firstname,
        "lastName" => $lastname,
        "email"    => $email,
        "ph_number"    => $ph_number,
        "cardnumber" => $cardnumber,
        "expmonth" => $expmonth,
        "expyear"    => $expyear,
        "card_cvv"    => $card_cvv,
        "line1" => $bill_adr1,
        "line2" => $bill_adr2,
        "city" =>  $bill_city,
        "state" => $bill_state,
        "zip" =>   $bzip,
        "country" => $bill_country,
        "cmd"    => $cmd,
        "chargebee_cid" => $chargebee_cid
        ),
        "customer" => array(
        "user_id" => $current_user_id,
        "firstName" => $firstname,
        "lastName" => $lastname,
        "email" => $email,
        "ph_number"    => $ph_number,
        )
        ));
       
        
        return $result;
                 
        
        }
        
    }

    public function  checkmodeapi(){
        $test_mode_check = $this->lib->chargebee_get_option('test_mode');
        if ($test_mode_check=='Yes') {
        $api_key = $this->lib->chargebee_get_option('test_api_key');
        $api_domain = $this->lib->chargebee_get_option('test_domain');
        }else{
        $api_key = $this->lib->chargebee_get_option('api_key');
        $api_domain = $this->lib->chargebee_get_option('domain');
        }

        if (!empty($api_key) && !empty($api_domain)) {
        return array('api_key' => $api_key,'domain'=> $api_domain);

        }
        else
        {
        return array('msg' => 'Please put domain or api');
        }
    }

    public function getproductlist(){

        $setting = $this->checkmodeapi();  
        $api_key =  $setting['api_key'];
        $domain  =  $setting['domain'];

        $this->lib->chargebee_library($domain,$api_key);

        ChargeBee_Environment::configure($domain,$api_key);
        
        $result = ChargeBee_Plan::all(array("status[is]" => "active"));
        
        return $result;
    }

    
    public function insertchargebeeproduct(){

       $getproductlist = $this->getproductlist();

        foreach($getproductlist as $entry) {

        $plan = $entry->plan();

        $title = $plan->name;
        $price = $plan->price/100;
        $contents =  '[single_post]';
        $post_name = $plan->id;   
        $description = $plan->description;    
        $check  =  $this->checkduplicateentry($post_name); 
        if($check && !empty($check))
        {
             $post = array(
                   'ID'            => $check,
                  'post_content'   => $contents,// The full text of the post.
                  'post_name'      => $post_name ,// The name (slug) for your post
                  'post_title'     => $title ,
                 
                  'post_status'    => 'publish' , // Default 'draft'.
                  'post_type'      => 'chargebee', // Default 'post'.
                  'post_author'   =>  1,

                  
                  );
                
                $post_id = wp_update_post($post); 
                
                $this->lib->chargebee_update_post_meta($post_id, 'title',$title);
                $this->lib->chargebee_update_post_meta($post_id, 'price',$price);
                $this->lib->chargebee_update_post_meta($post_id, 'contents',$contents);
                $this->lib->chargebee_update_post_meta($post_id, 'description',$description);
                $this->lib->chargebee_update_post_meta($post_id, 'post_name',$post_name);

        }
        else
        {
                $post = array(
                  'post_content'   => $contents,// The full text of the post.
                  'post_name'      => $post_name ,// The name (slug) for your post
                  'post_title'     => $title , // The title of your post.

                  'post_status'    => 'publish' , // Default 'draft'.
                  'post_type'      => 'chargebee', // Default 'post'.
                  'post_author'   =>  1,
                  
                  );
                
                $post_id = wp_insert_post($post); 
                
                $this->lib->chargebee_update_post_meta($post_id, 'title',$title);
                $this->lib->chargebee_update_post_meta($post_id, 'price',$price);
                $this->lib->chargebee_update_post_meta($post_id, 'contents',$contents);
                $this->lib->chargebee_update_post_meta($post_id, 'description',$description);
                $this->lib->chargebee_update_post_meta($post_id, 'post_name',$post_name);      
               
        }

        }                
        
        }   
    
    public function setdata(){

         $mode         =      $this->lib->chargebee_get_option('test_mode');
         $api_key      =      $this->lib->chargebee_get_option('api_key');
         $domain       =      $this->lib->chargebee_get_option('domain');
         $test_api_key =      $this->lib->chargebee_get_option('test_api_key');
         $test_domain  =      $this->lib->chargebee_get_option('test_domain');

         return array('test_mode' => $mode ,'api_key'=> $api_key ,'domain'=> $domain ,'test_api_key'=> $test_api_key ,'test_domain'=> $test_domain);
        

    }

    public function checkduplicateentry($title){

        global $wpdb;
        $result = $wpdb->get_row( "SELECT ID FROM wp_posts WHERE post_name = '" . $title . "' && post_status = 'publish' && post_type = 'chargebee' ", OBJECT);

        if($result) {
        return $result->ID;
        } else {
        return $result->ID;
        }

    }

    

      
} 