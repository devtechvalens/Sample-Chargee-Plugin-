<?php  
class Addmetabox {

    public function __construct()
    {    
         $this->lib = new ChargebeeLibrary();
    }

    public function  insert_meta_box_value($postdata){
          $data_title = sanitize_text_field($postdata['metabox_title']);
          $data_saving = sanitize_text_field($postdata['metabox_saving']);
          $data_separately = sanitize_text_field($postdata['metabox_separately']);
          $data_include = sanitize_text_field($postdata['metabox_include']);
          $data_masks = sanitize_text_field($postdata['metabox_masks']);
          $data_cushions = sanitize_text_field($postdata['metabox_cushions']);
          $data_tub = sanitize_text_field($postdata['metabox_tub']);
          $data_filters = sanitize_text_field($postdata['metabox_filters']);
          $data_tubings = sanitize_text_field($postdata['metabox_tubings']);
          
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'metabox_title', $data_title);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'metabox_saving', $data_saving);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'metabox_separately', $data_separately);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'metabox_include', $data_include);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'metabox_masks', $data_masks);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'metabox_cushions', $data_cushions);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'metabox_tub', $data_tub);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'metabox_filters', $data_filters);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'metabox_tubings', $data_tubings);

    }

    public function  insert_mask_box_value($postdata){
      
          $mask_1 = sanitize_text_field($postdata['mask_1']);
          $mask_2 = sanitize_text_field($postdata['mask_2']);
          $mask_3 = sanitize_text_field($postdata['mask_3']);
          $mask_4 = sanitize_text_field($postdata['mask_4']);
                   
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'mask_1', $mask_1);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'mask_2', $mask_2);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'mask_3', $mask_3);
          $this->lib->chargebee_update_post_meta($postdata['ID'], 'mask_4', $mask_4);

    }

   }