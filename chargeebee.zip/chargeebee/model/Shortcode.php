<?php  
class Shortcode {

    
public function __construct(){
}
    
public function singleplan($attr, $plan_slug){
            

    if($attr=='') {                    // all product get 

        $args = array(
        'post_type'   => 'chargebee',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        );

        $results = get_posts($args);
        return $results;
    }


    else if($attr=='product_code') {  // single  product get 

        $args = array(
        'name'        => $plan_slug,
        'post_type'   => 'chargebee',
        'post_status' => 'publish',
        'numberposts' => 1
        );

        $results = get_posts($args);
        return $results;
    }

    else if(trim($attr)=='category') { // category wise product get

        $args = array(
        'post_type' => 'chargebee',
        'posts_per_page' => -1,
        'tax_query' => array(array(
        'taxonomy' => 'chargebee_category',
        'field' => 'term_id',
        'terms' => explode(',', $plan_slug)
        ))

        );

        $results = get_posts($args);
        return array('results' =>$results,'category_id'=>$plan_slug);       
    }  

    else if($attr=='single_post'){

        $results = get_post($plan_slug);
        return $results;


    }

}
   


}