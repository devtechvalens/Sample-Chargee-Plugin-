<?php
class AddmetaboxController
{
	 private $lib;
	 private $tpl;
	 private $mdl;
	
	function __construct()
	{
		  $this->lib = new ChargebeeLibrary();
		  $this->tpl = new Template();

		  include_once(SUSCRIPTION_CHARGEBEE_DIR.'model/Addmetabox.php');    
		  $this->mdl = new Addmetabox();
		  add_action('add_meta_boxes', array($this, 'cs_add_meta_box'));
      add_action('save_post', array($this, 'save'));
      $this->mask_section_function();
      
	}

     public function cs_add_meta_box() {
               add_meta_box('cs-meta',
               'Add Chargebee Field',
               array($this, 'cs_meta_box_function'),
               'chargebee',
               'normal',
               'high');
     }

     public function cs_meta_box_function($post) {

    wp_nonce_field('cs_nonce_check', 'cs_nonce_check_value');
    $meta_box_arrays = $this->lib->get_meta_box_value($post->ID);
    echo $this->tpl->load('view/subscription-metabox-field',array('results'=>$meta_box_arrays));  
             

     }

     public function save($post_id) {

      $this->mdl->insert_meta_box_value($_POST);  
            
     }

     public function mask_section_function(){

      add_action('save_post', array($this, 'mask_save'));
      add_action('add_meta_boxes', array($this, 'mask_add_meta_box'));
     }


      public function mask_add_meta_box(){
      add_meta_box('mask-meta',
               'Mask Chargebee Field',
               array($this, 'mask_meta_box_function'),
               'chargebee',
               'normal',
               'high');

     }

    public function mask_meta_box_function($post) {

    //wp_nonce_field('cs_nonce_check', 'cs_nonce_check_value');
    $meta_box_arrays = $this->lib->get_mask_box_value($post->ID);
    echo $this->tpl->load('view/subscription-metabox-mask',array('results'=>$meta_box_arrays));  
             

     }
     
     public function mask_save($post_id) {

       $this->mdl->insert_mask_box_value($_POST);

            
     }

}