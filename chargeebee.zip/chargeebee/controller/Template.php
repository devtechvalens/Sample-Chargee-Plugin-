<?php   
class Template {  

     public function load( $tpl, $arr = array(),$type='',$return = false) {
          $path = SUSCRIPTION_CHARGEBEE_DIR.$tpl.'.php';
     if( file_exists($path) ) {
          foreach( $arr as $key => $value ) {
               $$key = $value;
          }
          unset( $arr );

          ob_start();
          require_once( $path );
          $template = ob_get_contents();
          ob_end_clean();

          if( $return == false ) {
               echo $template;
          } else {
               return $template;
          }
     } else {
          return false;
     }
}
     

}