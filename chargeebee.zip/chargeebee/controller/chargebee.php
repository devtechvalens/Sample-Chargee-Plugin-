<?php 
include_once(SUSCRIPTION_CHARGEBEE_DIR. 'model/Setting.php');  
class ChargeBeePlugin {  
     public $setting;
     protected $template;
     public function __construct()    
     {    
          $this->setting  = new Setting();
          $this->lib      = new ChargebeeLibrary();
          $this->template = new Template(); 
     }   
      
     public function apisetting()  
     {  
               
          $setting = $this->setting->insertapi();
          $setdata = $this->setting->setdata();
          echo $this->template->load('view/subscription_chargebee-view_list',array('result'=>$setdata));  
                
     }  

     public function productlist()

     {    
          $product =  $this->setting->insertchargebeeproduct();
          $result  =  $this->setting->getproductlist();
          echo $this->template->load('view/subscription_chargebee-product',array('result'=>$result));
     }
     

}