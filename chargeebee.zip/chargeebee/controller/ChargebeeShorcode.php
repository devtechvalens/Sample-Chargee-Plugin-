<?php 
class ChargebeeShorcode {  
     private $shortcode_tag = 'product_subscription';
     private $shortcode;
     private $tpl;
     private $lib;
     private $setting;

      public function __construct()    
      {    
         
          include_once(SUSCRIPTION_CHARGEBEE_DIR. 'model/Setting.php');
          include_once(SUSCRIPTION_CHARGEBEE_DIR. 'model/Shortcode.php');
          include_once(SUSCRIPTION_CHARGEBEE_DIR.'files/chargebee_api/chargebee-php-master/lib/ChargeBee.php');
          add_shortcode( 'product_subscription', array($this, 'showshortcode' ) );
          add_shortcode( 'single_post', array($this, 'show_single_shortcode' ) );
          $this->lib = new ChargebeeLibrary();
          $this->shortcode = new Shortcode();
          $this->tpl = new Template();
          $this->setting = new Setting();
      }
   
      public  function showshortcode($atts) {
 
          if($atts==NULL){

               $plan_slug = 'chargebee';      // all plan show 

               $atts=NULL;
               $plan_result  =  $this->shortcode->singleplan($atts,$plan_slug);
               echo $this->tpl->load('view/subscription_chargebee_plan', array('results'=>$plan_result),$type=$plan_slug);
                        
          }

          else if($atts['product_code']) {
                $plan_slug = $atts['product_code'];      //  all custom plan  show 
                $atts='product_code';
                $plan_result  =  $this->shortcode->singleplan($atts,$plan_slug);
                echo $this->tpl->load('view/subscription_chargebee_plan', array('results'=>$plan_result),$type=$atts);  
          }

          else if($atts['category']) {
                $plan_slug = $atts['category'];           //  all custom category wise plan  show 
                $atts='category';                
                $plan_result  =  $this->shortcode->singleplan($atts,$plan_slug);
                echo $this->tpl->load('view/subscription_chargebee_plan', array('results'=>$plan_result),$type=$plan_slug);
               
          }
      }

      public function show_single_shortcode(){         
                       
                $plan_slug = get_the_ID();
                $atts='single_post';                
                $plan_result  =  $this->shortcode->singleplan($atts,$plan_slug);                
                echo $this->tpl->load('view/subscription_chargebee_single_plan', array('results'=>$plan_result),$type=$plan_slug);
                
                $setting = $this->setting->insert_subscription();
                
      }


}
$obj_short = new ChargebeeShorcode();