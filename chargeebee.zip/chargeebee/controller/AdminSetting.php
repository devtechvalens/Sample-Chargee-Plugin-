<?php

/**
 * 
 */
include_once(SUSCRIPTION_CHARGEBEE_DIR. 'controller/Chargebee.php');

class AdminSetting
{            
	        protected $charge_b;
			function __construct()
			{   
				include_once(SUSCRIPTION_CHARGEBEE_DIR. 'controller/Addmetabox.php');
				$this->charge_b =  new ChargeBeePlugin();
				add_action('admin_menu', array($this,'chargebee_create_menu'));
				$this->custom_posts_init();                
				
			}
	
		    public function chargebee_create_menu() {

            add_menu_page('Chargebee', //page title
			'Chargebee', //menu title
			'manage_options', //capabilities
			'subscription_chargebee_setting_api', //menu slug
			array($this,'subscription_chargebee_setting_api') //function
			);

			//this is a submenu
			add_submenu_page('subscription_chargebee_setting_api', //parent slug
			'Setting', //page title
			'Setting', //menu title
			'manage_options', //capability
			'subscription_chargebee_setting_api', //menu slug
			array($this,'subscription_chargebee_setting_api')); //function

			
			add_submenu_page('subscription_chargebee_setting_api', //parent slug
			'Products', //page title
			'Products', //menu title
			'manage_options', //capability
			'subscription_chargebee_product', //menu slug
			array($this,'subscription_chargebee_product')); //function

            
    
        }

        public function subscription_chargebee_setting_api() {

		$this->charge_b->apisetting();

        }



        public function subscription_chargebee_product() {
        include_once(SUSCRIPTION_CHARGEBEE_DIR.'files/chargebee_api/chargebee-php-master/lib/ChargeBee.php');  
		$this->charge_b->productlist();	 
        }

        function custom_posts_init() {
		    // set up product labels
		    $labels = array(
		        'name' => 'Chargebee Subscription',
		        'singular_name' => 'Chargebee Subscription',
		        'add_new' => 'Add New Chargebee Subscription',
		        'add_new_item' => 'Add New Chargebee Subscription',
		        'edit_item' => 'Edit Chargebee Subscription',
		        'new_item' => 'New Chargebee Subscription',
		        'all_items' => 'All Chargebee Subscription',
		        'view_item' => 'View Chargebee Subscription',
		        'search_items' => 'Search Chargebee Subscription',
		        'not_found' =>  'No Chargebee Subscription Found',
		        'not_found_in_trash' => 'No Chargebee Subscription found in Trash', 
		        'parent_item_colon' => '',
		        'menu_name' => 'Chargebee Subscription',

		    );
		    
		    // register post type
		    $args = array(
		        'labels' => $labels,
		        'public' => true,
		        'has_archive' => true,
		        'show_ui' => true,
		        'capability_type' => 'post',
		        'hierarchical' => false,
		        'rewrite' => array('slug' => 'chargebee'),
		        'query_var' => true,
		        'menu_icon' => 'dashicons-randomize',

		        'supports' => array(
		            'title',
		            'editor',
		            'excerpt',
		            
		            'comments',
		            'revisions',
		            'thumbnail',
		            
		            
		        ),
		        'taxonomies' => array('post_tag')
		    );
		    register_post_type( 'chargebee', $args );
		    
		    // register taxonomy
		    register_taxonomy('chargebee_category', 'chargebee', array('hierarchical' => true, 'label' => 'Category', 'query_var' => true, 'rewrite' => array( 'slug' => 'chargebee-category' )));

          $amb = new AddmetaboxController();
            
		}
}